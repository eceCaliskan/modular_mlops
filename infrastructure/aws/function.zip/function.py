def lambda_handler(event, context):
    # 1. The Handler
    print("Received event:", event)
    
    # Your business logic here
    message = "Hello, " + event.get("key1", "World")
    
    return {
        'statusCode': 200,
        'body': message
    }